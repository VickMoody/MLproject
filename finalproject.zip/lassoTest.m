function y = lassoTest(w, Xtest,b)

    y=b+Xtest*w;
end