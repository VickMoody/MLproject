function [w,b] = lassoTrain(Xtr, Ytr, lambda)
    
    n = size(Xtr,1);
    d = size(Xtr,2);
    w = rand(d,1);
    maxiter = 10;
    errate = 10000;
    thresh = 0.001;
    stepsize = (Xtr'*Xtr);
    i = 2;
%     disp(size(w));
%     disp(size(Xtr));
%     disp(size(Ytr));
grw = zeros(d,maxiter+1);
% grw(:,1) = 0;
proxw = zeros(d,maxiter);
    while((i<maxiter)||(errate<thresh))
     
        grw(:,i) = grw(:,i-1) - (stepsize*(Xtr'*(Ytr-Xtr*grw(:,i-1))));

        for k =1:d
            if(grw(k,i)>lambda)
                proxw(k,i-1)= grw(k,i)-lambda;
            elseif(grw(k,i-1)<-lambda)       
                proxw(k,i-1)= grw(k,i)+lambda;
            else
                proxw(k,i-1) = 0;
            end
        end

    i = i+1;
    end
     ymtr = sum(Ytr)/length(Ytr);
    for i = (1:size(Xtr,2))
        xmtr(1,i) = sum(Xtr(:,i))/length(Xtr);
    end
    yctr = Ytr - ymtr;
    for i = (1:size(Xtr,2))
        xctr(:,i) = Xtr(:,i) - xmtr(i);
    end      
    b = ymtr - xmtr*w;

end