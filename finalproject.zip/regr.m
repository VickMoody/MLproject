function t1 = regr()
% performs the regression on data, having the response value - average mark
% of two semesters G1+G2/2 (preprocessed previously)
% output = the table of input data and response values:
%          concatenation of correct data from training datasets and test
%          prediction that can be seen as a noise.


% input data
inputfile = 'student-por.xlsx';
yfile = 'ypor.xlsx';
inputdata = readtable(inputfile);
outputdata = xlsread(yfile);


% splitting data into training and testing set
erroccur = 0;
% training percentage input error check
while (erroccur==0)
    trainperc = input('percentage of training set(suggestion 0.8) \n');
    if(trainperc<1)
        erroccur = 1;
    else
        disp('Error: your number should be in range 0-1');
        erroccur = 0;
    end
end
[xtrain,ytrain,xtest,ytest,Itr,Its] = randSplit(inputdata,outputdata,trainperc);

% validation percentage input error check
% (calculated from training partition)
erroccur = 0;
while (erroccur==0)
    valper = input('percentage of validation set (suggestion 0.2) \n');
    if(valper<1)
        erroccur = 1;
    else
        disp('Error: your number should be in range 0-1');
        erroccur = 0;
    end
end
% kfold number error check, should not be greater than 20 because of 
% too much time consumption.
erroccur = 0;
while (erroccur==0)
    nfold = input('number of CV folds (suggestion 10) \n');
    if(nfold<20)
        erroccur = 1;
    else
        disp('Error: your number should be in range 0-20 otherwise it takes too much time');
        erroccur = 0;
    end
end


% lambda input error check

erroccur = 0;
while (erroccur==0)
    condition1 = input('press 1 for default lambda or 2 for entering your desired values\n');
    if (condition1==1)
        lambda = [0.0001,0.001,0.01,1,10,100];
        erroccur = 1;
    elseif (condition1==2)
        lambda = input('please enter 6 values for lambda using this notation [value1,value2...]\n');  
        erroccur = 1;
    else
        disp('Error: please first enter 1 or 2 to choose the input method');
        erroccur = 0;
    end
end


% sigma input error check

erroccur = 0;
while (erroccur==0)
    condition1 = input('press 1 for default sigma or 2 for entering your desired values\n');
    if (condition1==1)
        sigma = linspace(0.1,10,6);
        erroccur = 1;
    elseif (condition1==2)
        lambda = input('please enter 6 values for sigma using this notation [value1,value2...]\n');  
        erroccur = 1;
    else
        disp('Error: please first enter 1 or 2 to choose the input method');
        erroccur = 0;
    end
end

kernel = 'gaussian';
toKeep = true(size(xtrain(1,:)));
% different types of dimensionality reduction
disp(['enter 0 to keep all features',newline,'1 for pca',newline,...
    '2 for sequential selection',newline,'3 for pca+seq selection',newline,...
    '4 for seq selection +pca',newline,' suggestion 4',newline]);
dimred = input('your choice is:\n');
if(dimred == 0)   
elseif(dimred == 1)
    [pcacoef,score,~,~,expl,~] = pca(xtrain);
    figure('Name','PCA variance(regression scenario)');
    set(gcf, 'Position', [600, 50, 500, 500]);
    pareto(expl);
    xtrain = score(:,1:10);
    [~,score,~,~,expl,~] = pca(xtest);
    xtest = score(:,1:10);
    toKeep = true(size(xtrain(1,:)));
elseif(dimred == 2)
    
%     errf = @(Xtrain,Ytrain,Xtest,Ytest) sum((Ytest - predict(fitlm(Xtrain,Ytrain,'purequadratic'),Xtest)).^2)/length(Ytest);
%     toKeep = sequentialfs(errf,xtrain,ytrain);
    errf = @(Xtrain,Ytrain,Xtest,Ytest) sum((Ytest - predict(fitrsvm(Xtrain,Ytrain,'KernelFunction',kernel,'Standardize',true),Xtest)).^2)/length(Ytest);
    toKeep = sequentialfs(errf,xtrain,ytrain);

elseif(dimred == 3)
    [~,score,~,~,expl,~] = pca(xtrain);
    figure('Name','PCA variance(regression scenario before var selection)');
    set(gcf, 'Position', [600, 50, 500, 500]);
    pareto(expl);
    xtrain = score(:,1:10);
    [~,score,~,~,expl,~] = pca(xtest);
    xtest = score(:,1:10);
    toKeep = true(size(xtrain(1,:)));
    
%     errf = @(Xtrain,Ytrain,Xtest,Ytest) sum((Ytest - predict(fitlm(Xtrain,Ytrain,'purequadratic'),Xtest)).^2)/length(Ytest);
    errf = @(Xtrain,Ytrain,Xtest,Ytest) sum((Ytest - predict(fitrsvm(Xtrain,Ytrain,'KernelFunction',kernel,'Standardize',true),Xtest)).^2)/length(Ytest);

toKeep = sequentialfs(errf,xtrain,ytrain);
elseif(dimred==4)
    errf = @(Xtrain,Ytrain,Xtest,Ytest) sum((Ytest - predict(fitrsvm(Xtrain,Ytrain,'KernelFunction',kernel,'Standardize',true),Xtest)).^2)/length(Ytest);
    toKeep = sequentialfs(errf,xtrain,ytrain);
    
    [~,score,~,~,expl,~] = pca(xtrain(:,toKeep));
    figure('Name','PCA variance(regression scenario after var selection)');
    set(gcf, 'Position', [600, 50, 500, 500]);
    pareto(expl);
    xtrain = score(:,1:nnz(toKeep));
    [~,score,~,~,expl,~] = pca(xtest(:,toKeep));
    xtest = score(:,1:nnz(expl));
    toKeep = true(size(xtrain(1,:)));
else
    print('Error: no such option found');
end

    disp(['--------------- LINEAR MODEL type ',num2str(dimred),' ---------------']);
    [~, ~, Vm, Vs, Tm, Ts] = crossVal('lr', xtrain(:,toKeep), ytrain,[], valper, nfold, 0, []);
    disp([num2str(nfold),' Fold Train mse = ',num2str(Tm)]);
    disp([num2str(nfold),' Fold validation mse = ',num2str(Vm)]);
    mdlLm= fitlm(xtrain(:,toKeep),ytrain,'purequadratic');
    ypredLm = (predict(mdlLm,xtest(:,toKeep)));
    sse = 0;
        for i=1:length(ypredLm)
            sse = sse+(ypredLm(i,1)-ytest(i,1))^2;
        end
    teMseLm = sse/length(ypredLm);
    disp(['test MSE = ',num2str(teMseLm)]);
        
    disp(['---------------RLS type',num2str(dimred),' ---------------']);
    [lRLS, ~, Vm, Vs, Tm, Ts] = crossVal('rlr', xtrain(:,toKeep), ytrain,[], valper, nfold, lambda, []);
    disp([num2str(nfold),' Fold Train mse on different lambda']);
    disp(Tm);
    disp([num2str(nfold),' Fold Validation mse on different lambda']);
    disp(Vm);

    [wRLS,bRLS] = rLSTrain(xtrain(:,toKeep),ytrain,lRLS);
    ypredRLS = rLSTest(wRLS, xtest(:,toKeep),bRLS);
    sse = 0;
        for i=1:length(ypredRLS)
            sse = sse+(ypredRLS(i,1)-ytest(i,1))^2;
        end
    teMseRLS = sse/length(ypredRLS);
    disp(['test MSE = ',num2str(teMseRLS)]);

    disp(['---------------RLS LASSO type ',num2str(dimred),' ---------------']);
    [lLa, ~, Vm, Vs, Tm, Ts] = crossVal('rlr2', xtrain(:,toKeep), ytrain,[], valper, nfold, lambda, []);
    disp([num2str(nfold),' Fold Train mse on different lambda']);
    disp(Tm);
    disp([num2str(nfold),' Fold Validation mse on different lambda']);
    disp(Vm);
    [wLa,bLa] = lassoTrain(xtrain(:,toKeep),ytrain,lLa);
    ypredLa = lassoTest(wLa,xtest(:,toKeep),bLa);
    sse = 0;
        for i=1:length(ypredLa)
            sse = sse+(ypredLa(i,1)-ytest(i,1))^2;
        end
    teMseLa = sse/length(ypredLa);
    disp(['test MSE = ',num2str(teMseLa)]);

    disp(['---------------KERNEL RLS type ',num2str(dimred),' ---------------']);
    
    [lKLS, sKLS, Vm, Vs, Tm, Ts] = crossVal('krls', xtrain(:,toKeep), ytrain,kernel, valper, nfold, lambda, sigma);
    disp([num2str(nfold),' Fold Train mse on different lambda and sigma']);
    disp(Tm);
    disp([num2str(nfold),' Fold Validation mse on different lambda and sigma']);
    disp(Vm);
    cKLS = rKLSTrain(xtrain(:,toKeep), ytrain, kernel, sKLS, lKLS);
    ypredKLS = rKLSTest(cKLS, xtrain(:,toKeep), kernel, sKLS, xtest(:,toKeep));
    sse = 0;
        for i=1:length(ypredKLS)
            sse = sse+(ypredKLS(i,1)-ytest(i,1))^2;
        end
    teMseKLS = sse/length(ypredKLS);
    disp(['test MSE = ',num2str(teMseKLS)]);

    disp(['---------------rSVM type ',num2str(dimred),' ---------------']);
    [~, ~, Vm, Vs, Tm, Ts] = crossVal('rsvm', xtrain(:,toKeep), ytrain,kernel, valper, nfold, 0, []);
    disp([num2str(nfold),' Fold Train mse ']);
    disp(Tm);
    disp([num2str(nfold),' Fold Validation mse ']);
    disp(Vm);
    mdlSVM = fitrsvm(xtrain(:,toKeep),ytrain,'KernelFunction',kernel,'Standardize',true);
    ypredSVM =(predict(mdlSVM,xtest(:,toKeep)));
    sse = 0;
        for i=1:length(ypredSVM)
            sse = sse+(ypredSVM(i,1)-ytest(i,1))^2;
        end
    teMseSVM = sse/length(ypredSVM);
    disp(['test MSE = ',num2str(teMseSVM)]);
    
    yfinal = zeros((length(ytrain)+length(ypredKLS)),1);
    yfinal(Itr) = ytrain;
    yfinal(Its) = ypredKLS;
    
    xfinal = cell2mat(table2cell(inputdata));
    t1 = horzcat(xfinal,yfinal);
    res(:,1) = [teMseKLS,teMseLa, teMseLm, teMseRLS,teMseSVM];
    res(:,2) =[lKLS,lLa,0,lRLS,0];
    res(:,3) = [sKLS,0,0,0,0];
    x = categorical({'KLS','Lasso', 'Lm', 'RLS','SVM'});
    x = reordercats(x,{'KLS' 'SVM' 'Lm' 'RLS' 'Lasso' });
    y = res(:,1);
    figure('Name','Performance comparison');
    set(gcf, 'Position', [0, 100, 600, 650]);
    
    subplot(2,1,1);
%     title(ax1,'Subplot 1')
    b = bar(x,y);
    b.FaceColor = 'flat';
    b.CData(2,:) = [0 0 0.2];
    b.CData(3,:) = [0 0 0.2];
    b.CData(4,:) = [0 0 0.2];
    b.CData(5,:) = [0 0 0.2];
    b.CData(1,:) = [0 0 0.1];
    xlabel('Algorithm');
    ylabel('TestMSE');
    text(x,y+0.3,num2str(y));
    print('barchart','-dpng');

    subplot(2,1,2);
%     title(ax2,'Subplot 2')
    uitable('Data', res , 'ColumnName', {'TestMSE', 'Optimal Lambda', 'Optimal Sigma'}, 'Position', [100 80 300 150]);
    
    figure('Name','PieChart');
    stpass = 0;
    strisk = 0;
    stfail = 0;
    for i = 1:length(ypredKLS)
        if(ypredKLS(i,1)>10+sqrt(teMseKLS))
            stpass = stpass+1;
        elseif(ypredKLS(i,1)<10-sqrt(teMseKLS))
            stfail = stfail +1;
        else
            strisk = strisk+1;
        end
    end
    vect = [stpass,strisk,stfail];
    pie(vect,{'Pass','At Risk','Fail'});
    print('piechart','-dpng');
    stpass1 = 0;
    strisk1 = 0;
    stfail1 = 0;
    for i = 1:length(ytest)
        if(ytest(i,1)>10+sqrt(teMseKLS))
            stpass1 = stpass1+1;
        elseif(ytest(i,1)<10-sqrt(teMseKLS))
            stfail1 = stfail1 +1;
        else
            strisk1 = strisk1+1;
        end
    end
    

end
    
   
    

