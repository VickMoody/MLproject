function [l, s, Vm, Vs, Tm, Ts] = crossVal(algorithm, X, Y, kernel, perc, nrip, intRegPar, intKerPar)
% algorithm =   'lr' least squares
%               'rlr' regularized least squares
%               'rlr2' regularized least squares with absolute value of
%               parameters in penalty term
%               'krls' kernel regularized least squares,
%               'rsvm' support vector machine for regression
%               'knn' K-nearest neighbour
% X: the training examples
% Y: the training labels
% kernel: the kernel function = 'linear'
%                               'polynomial'
%                               'gaussian'
% perc: fraction of the dataset to be used for validation
% nrip: number of repetitions of the test for each couple of parameters
% intRegPar: list of regularization parameters (lambda)
% intKerPar: list of kernel parameters (sigma)
%
% Output:
% l, s: the couple of regularization and kernel parameter that minimize the mse of the
%       validation error
% Vm, Vs: mean and variance of the validation error for each couple of parameters
% Tm, Ts: mean and variance of the error computed on the training set for each couple
%       of parameters
%
% 
    if isequal(algorithm,'lr') || isequal(algorithm,'rlr') || isequal(algorithm,'rlr2')|| isequal(algorithm,'knn') || isequal(algorithm,'rsvm')||isequal(kernel,'linear') || isequal(kernel,[])
        intKerPar = [0];
    end

    nKerPar = numel(intKerPar);
    nRegPar = numel(intRegPar);
 
    
    n = size(X,1);
    ntr = ceil(n*(1-perc));
    
    tmn = zeros(nRegPar, nKerPar, nrip);
    vmn = zeros(nRegPar, nKerPar, nrip);
    
    for rip = 1:nrip
        I = randperm(n);
        Xtr = X(I(1:ntr),:);
        Ytr = Y(I(1:ntr),:);
        Xvl = X(I(ntr+1:end),:);
        Yvl = Y(I(ntr+1:end),:);
        
        
        is = 0;
        for s=intKerPar
            is = is + 1;
            il = 0;  
            
            for l=intRegPar
                il = il + 1;
                if isequal(algorithm, 'lr')
%               Linear regression      
                    mdlLm= fitlm(Xtr,Ytr,'purequadratic');
                    tmn(il, is, rip) = mdlLm.MSE;  
                    vmn(il, is, rip)  = calcErr(predict(mdlLm,Xvl),Yvl);
                elseif isequal(algorithm, 'rlr')
%               Regularized Linear regression (squared parameters in penalty term)   
                    [w,b] = rLSTrain(Xtr,Ytr, l);
                    tmn(il, is, rip) =  calcErr(rLSTest(w, Xtr,b), Ytr);               
                    vmn(il, is, rip)  = calcErr(rLSTest(w, Xvl,b), Yvl);
                elseif isequal(algorithm, 'rlr2')
%               Regularized Linear regression (absolute value of parameters in penalty term)
                    [w,b] = lassoTrain(Xtr,Ytr,l);
                    tmn(il, is, rip) =  calcErr(lassoTest(w,Xtr,b), Ytr);               
                    vmn(il, is, rip)  = calcErr(lassoTest(w,Xvl,b), Yvl);
                elseif isequal(algorithm, 'krls')
%               Kernel regularized least squares
                    w = rKLSTrain(Xtr, Ytr, kernel, s, l);
                    tmn(il, is, rip) =  calcErr(rKLSTest(w, Xtr, kernel, s, Xtr), Ytr);               
                    vmn(il, is, rip)  = calcErr(rKLSTest(w, Xtr, kernel, s, Xvl), Yvl);                
                elseif isequal(algorithm, 'knn')
%               KNN for classification      
                   mdlKNN = fitcknn(Xtr,Ytr,'NumNeighbors',l);
                   tmn(il, is, rip) = resubLoss(mdlKNN);
                   vmn(il, is, rip)  = loss(mdlKNN,Xvl,Yvl);
                elseif isequal(algorithm, 'rsvm')
%               Regression Support Vector machine
                    mdlSVM = fitrsvm(Xtr,Ytr,'KernelFunction',kernel,'Standardize',true);
                    tmn(il, is, rip) = resubLoss(mdlSVM);
                    vmn(il, is, rip)  = calcErr(predict(mdlSVM,Xvl),Yvl);
                else
                    disp('no algorithm found');
                end
                
            end
        end
    end
    
    Tm = sum(tmn,3)/nrip;
    Ts = std(tmn,0,3);
    Vm = sum(vmn,3)/nrip;
    Vs = std(vmn,0,3);
    
    [row, col] = find(Vm <= min(min(Vm)));
    
    l = intRegPar(row(1));
    s = intKerPar(col(1));
end


function mse = calcErr(Pred,Real)
    sse = 0;
    for i=1:length(Pred)
        sse = sse+(Pred(i,1)-Real(i,1))^2;
    end
mse = sse/length(Pred);
end

