function y = rLSTest(w, Xtest,b)
    y=b+Xtest*w;
end