function [Xtr Ytr Xts Yts I1 I2] = randSplit(X, Y, perc)
    n = size(X,1);
    n_train = round(n*perc);
    I = randperm(n);
    I1 = I(1:n_train);
    I2 = I((n_train+1):(n));
    
    Xtr = cell2mat(table2cell(X(I1,:)));
    Ytr = Y(I1);
    
    Xts = cell2mat(table2cell(X(I2,:)));
    Yts = Y(I2);
end