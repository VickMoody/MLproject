function [w,b] = rLSTrain(Xtr, Ytr, lambda)
    ymtr = sum(Ytr)/length(Ytr);
    for i = (1:size(Xtr,2))
        xmtr(1,i) = sum(Xtr(:,i))/length(Xtr);
    end
    yctr = Ytr - ymtr;
    for i = (1:size(Xtr,2))
        xctr(:,i) = Xtr(:,i) - xmtr(i);
    end      
	n = size(Xtr,1);
    d = size(Xtr,2);
    Id = eye(d);
    w = inv(((Xtr'*Xtr)+(lambda*n*Id)))*Xtr'*Ytr;
    b = ymtr - xmtr*w;
%     disp(b);
end