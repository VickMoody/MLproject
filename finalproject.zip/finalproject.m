y = readtable('doubleclassresp.xlsx');
y = y{:,:};
y = categorical(y);
ydum = dummyvar(y);
xx = regr();
errf = @(Xtrain,Ytrain,Xtest,Ytest) loss(fitcknn(Xtrain,Ytrain,'NumNeighbors',5),Xtest,Ytest)/length(Ytest);
toKeep = sequentialfs(errf,xx,y);
% PCA
[~,scrs,~,~,pexp] = pca(xx(:,toKeep));
x = scrs(:,1:nnz(pexp));
% som = selforgmap([10 10]);
% clusternet = train(som,x');
% % Sample hits
% figure(1)
% plotsomhits(clusternet,x')
% % Neighbor distances
% figure(2)
% plotsomnd(clusternet)

% % Weight planes
% figure(3)
% plotsomplanes(clusternet)
% response value

%% Initialize Neural Network
patternrecnet = patternnet(10,'trainbr', 'mse');
patternrecnet.divideParam.trainRatio = 70/100;
patternrecnet.divideParam.valRatio = 15/100;
patternrecnet.divideParam.testRatio = 15/100;
%% Train the network
[patternrecnet,tr] = train(patternrecnet,x',ydum');
%% Predict response;
x1 = x';
scoreTest = patternrecnet(x1(:,tr.testInd));
[~,yPred] = max(scoreTest);
%% Evaluate classification with confusion matrix
ytest = y(tr.testInd);
yT = dummyvar(ytest);
yP = dummyvar(categorical(yPred'));
plotconfusion(yT',yP','pattern net');
print('pattern conf','-dpng');
%% Determine test error
paternrectestErr = 100*nnz(yPred' ~= double(ytest))/length(ytest);
disp(['The pattern recognition network test error is ',num2str(paternrectestErr),'%'])

%% function fitting network
% Create a Fitting Network
hiddenLayerSize = [3 3];
funcfitnet = fitnet(hiddenLayerSize,'trainbr');
% Set up Division of Data for Training, Validation, Testing
funcfitnet.divideParam.trainRatio = 70/100;
funcfitnet.divideParam.valRatio = 15/100;
funcfitnet.divideParam.testRatio = 15/100;
% Train the Network
[funcfitnet,tr1] = train(funcfitnet,x',ydum');
% Test the Network
outputs = funcfitnet(x1(:,tr1.testInd));
[~,ypred1] = max(outputs);
ytest1 = y(tr1.testInd);
yT1 = dummyvar(ytest1);
yP1 = dummyvar(categorical(ypred1'));
plotconfusion(yT1',yP1','fitting net');
print('fit conf','-dpng');
backproptestErr = 100*nnz(ypred1' ~= double(ytest1))/length(ytest1);
disp(['The fitting network test error is ',num2str(backproptestErr),'%'])
%errors = gsubtract(outputs,targets);
%performance = perform(backpropnet,targets,outputs)
% View the Network
view(funcfitnet)
% Plots
% Uncomment these lines to enable various plots.
% figure, plotperform(tr)
% figure, plottrainstate(tr)
% figure, plotfit(targets,outputs)
%% importing data
%x = readtable('student-por.xlsx');
y = readtable('doubleclassresp.xlsx');
%x = x{:,:};
y = y{:,:};
%% normalizing data
nrmx = zscore(xx,1);
%% feature transformation
% sequential feature selection
[pcsnrm,scrsnrm,~,~,pexpnrm] = pca(nrmx(:,toKeep));%%performing PCA on normalized data
figure('name','eigenvalues of raw transformed data')
pareto(pexp)%%eigen values of raw PCA
figure('name','eigenvalues of normalized transformed data')
pareto(pexpnrm)%% eigen values of nrmalized PCA
%% dimensionity reduction
scrsreduced = scrs(:,1:nnz(pexp));
figure('name','3D view of first 3 principal components')
scatter3(scrsreduced(:,1),scrsreduced(:,2),y(:,1))
%% creating test and training data 
%%partitioning
percent1 = input('enter the percent of data you want to hold as test data\n');
ycat = categorical(y);
cvpt = cvpartition(ycat,'HoldOut',percent1);
trainingreduced = scrsreduced(training(cvpt),:);
testreduced = scrsreduced(test(cvpt),:);
trainingnrm = scrsnrm(training(cvpt),:);
testnrm = scrsnrm(test(cvpt),:);
ytrain = y(training(cvpt),:);
ytest = y(test(cvpt),:);
%% models
[k1, ~, Vm, Vs, Tm, Ts] = crossVal('knn', trainingreduced, ytrain,[], 0.1, 10, [2 3 4 5], []);
mdlknnred = fitcknn(trainingreduced,ytrain,'NumNeighbors',k1);
knntrloss = resubLoss(mdlknnred);
knntestloss = loss(mdlknnred,testreduced,ytest);
predicteddata = predict(mdlknnred,testreduced);
numoferror = nnz(predicteddata ~= ytest);
[k2, ~, Vm, Vs, Tm, Ts] = crossVal('knn', trainingnrm, ytrain,[], 0.1, 10, [2 3 4 5], []);
mdlknnnrm = fitcknn(trainingnrm,ytrain,'NumNeighbors',k2);
knnnrmtrloss = resubLoss(mdlknnnrm);
knnnrmtestloss = loss(mdlknnnrm,testnrm,ytest)
mdlnb = fitcnb(trainingreduced,ytrain,'KFold',10,'Distribution','kernel');
nbkfoldLoss = kfoldLoss(mdlnb)
barvector = [backproptestErr paternrectestErr 100*knnnrmtestloss 100*knntestloss 100*nbkfoldLoss];
figure('name','bar view of test errors')
c = categorical({'fitting net','patern net','nrm knn', 'raw knn', 'nb kfoldloss'});
values = barvector';
b = bar(c,values);
b.FaceColor = 'flat';
b.CData(2,:) = [0 0 0.2];
b.CData(3,:) = [0 0 0.2];
b.CData(1,:) = [0 0 0.1];
b.CData(5,:) = [0 0 0.2];
b.CData(4,:) = [0 0 0.1];
xlabel('Algorithm');
ylabel('test error percent');
text(c,values+0.5,num2str(values));
print('barchart','-dpng');




